<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head><title>МОЗ - Головна</title><link rel="stylesheet" href="style.css"></head>
<body>
<h1>МОЗ: Система для лікарні</h1>
<p>Ласкаво просимо, <?php echo $_SESSION['username']; ?>!</p>
<nav>
    <a href="admin_dashboard.php">Кабінет головного лікаря</a> |
    <a href="deputy_dashboard.php">Кабінет заступника</a> |
    <a href="doctors.php">Лікарі</a> |
    <a href="patients.php">Пацієнти</a> |
    <a href="units.php">Підрозділи</a> |
    <a href="reports.php">Звіти</a> |
    <a href="logout.php">Вихід</a>
</nav>
</body>
</html>

<?php
session_start(); if (!isset($_SESSION['username'])) die('Доступ заборонено');
echo '<h1>Список лікарів</h1>';
?>
<table border="1">
<tr><th>Ім’я</th><th>Спеціальність</th><th>Вартість</th></tr>
<tr><td>Людмила Легенда</td><td>Судинна хірургія</td><td>3000 грн</td></tr>
<tr><td>Вадим Тичина</td><td>Кардіологія</td><td>2500 грн</td></tr>
</table>

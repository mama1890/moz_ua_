<?php
session_start();
include 'db.php';
$error = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $stmt = $conn->prepare("SELECT * FROM users WHERE username=? AND password=?");
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        if ($user['role'] == 'head') header("Location: admin_dashboard.php");
        else header("Location: deputy_dashboard.php");
        exit();
    } else $error = "Невірний логін або пароль!";
}
?>
<!DOCTYPE html>
<html>
<head><title>Вхід</title></head>
<body>
<h2>Вхід до системи</h2>
<form method="post">
    <input type="text" name="username" placeholder="Логін" required><br>
    <input type="password" name="password" placeholder="Пароль" required><br>
    <button type="submit">Увійти</button>
</form>
<p style="color:red;"><?php echo $error; ?></p>
</body>
</html>
